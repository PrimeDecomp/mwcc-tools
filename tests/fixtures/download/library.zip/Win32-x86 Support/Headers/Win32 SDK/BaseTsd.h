fixture: Win32-x86 Support/Headers/Win32 SDK/BaseTsd.h
