// synthetic patch input
#include <stdio.h>	// 960711: Wouldn't compile without it.

    MessageBox(NULL, buffer, TEXT("Unhandled Exception"), MB_OK | MB_TASKMODAL);
