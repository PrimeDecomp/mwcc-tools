fixture: MSL/MSL_C++/MSL_Common/Src/nested/fixture.c
