fixture: MSL/MSL_C/MSL_X86/nested/fixture.c
