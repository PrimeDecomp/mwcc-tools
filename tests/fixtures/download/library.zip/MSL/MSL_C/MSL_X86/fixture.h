fixture: MSL/MSL_C/MSL_X86/fixture.h
