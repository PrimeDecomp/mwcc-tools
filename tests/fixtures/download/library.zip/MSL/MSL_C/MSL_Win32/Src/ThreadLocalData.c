// synthetic patch input
	    MessageBox(NULL, TEXT("Could not get thread local data"), TEXT("MW Win32 Runtime"), MB_OK);
	    exit(0);
