// synthetic patch input
/*  Change Record
