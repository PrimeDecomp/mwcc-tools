// synthetic patch input
_HandleTable[0]->translate = 1;
_HandleTable[1]->translate = 1;
_HandleTable[2]->translate = 1;
