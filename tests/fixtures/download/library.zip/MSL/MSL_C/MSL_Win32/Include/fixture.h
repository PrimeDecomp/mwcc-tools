fixture: MSL/MSL_C/MSL_Win32/Include/fixture.h
