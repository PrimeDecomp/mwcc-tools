fixture: MSL/MSL_C/MSL_Common/Include/os_enum.h
