fixture: MSL/MSL_C/MSL_Common/Include/fixture.h
