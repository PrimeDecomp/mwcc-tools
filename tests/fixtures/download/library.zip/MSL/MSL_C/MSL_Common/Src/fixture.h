fixture: MSL/MSL_C/MSL_Common/Src/fixture.h
