// synthetic patch input
buff_ptr = "";      /*97010mani@be */
