// synthetic patch input
	time_t	time = __get_time();
		__time2tm(*timer, &tm);
struct tm * localtime(const time_t * timer)
